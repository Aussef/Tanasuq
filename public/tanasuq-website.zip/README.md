# Tanasuq Design Studio — Website Package

Complete HTML5, CSS3, and modern JavaScript website for Tanasuq boutique design company.

## Files Included
- index.html: Semantic, accessible HTML5 structure with top bar, hero showcase, philosophy pillars, filterable works grid, interactive scope estimator, case study modal, and contact consultation form.
- style.css: Modern responsive CSS with custom properties, 60-30-10 color discipline, zero-pill metadata, and fluid typography.
- app.js: Pure vanilla JavaScript engine handling responsive mobile navigation, project filtering, modal dialogs, real-time scope calculator, and validated form dispatch.
- images/: Curated photography assets for the studio and project portfolio.

## How to Run
1. Unzip the archive.
2. Open index.html directly in any web browser, or serve with any static web server (e.g., npx serve, live-server, or deploy to Vercel/Netlify/Cloudflare).
