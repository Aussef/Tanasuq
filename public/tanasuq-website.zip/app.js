/**
 * Tanasuq Design Studio — Interactive Application Engine
 * Pure Vanilla JavaScript (ES6+)
 */

document.addEventListener('DOMContentLoaded', () => {
  initMobileNav();
  initProjectFilters();
  initCaseStudyModal();
  initScopeEstimator();
  initContactForm();
  initCurrentYear();
});

/* --------------------------------------------------------------------------
 * 1. Mobile Navigation
 * -------------------------------------------------------------------------- */
function initMobileNav() {
  const toggleBtn = document.getElementById('mobileToggle');
  const drawer = document.getElementById('mobileDrawer');
  const navLinks = drawer.querySelectorAll('.mobile-nav-link, .btn');

  if (!toggleBtn || !drawer) return;

  function toggleMenu(open) {
    const isOpen = open !== undefined ? open : !drawer.classList.contains('open');
    toggleBtn.classList.toggle('active', isOpen);
    drawer.classList.toggle('open', isOpen);
    toggleBtn.setAttribute('aria-expanded', String(isOpen));
    drawer.setAttribute('aria-hidden', String(!isOpen));
    document.body.style.overflow = isOpen ? 'hidden' : '';
  }

  toggleBtn.addEventListener('click', () => toggleMenu());

  navLinks.forEach(link => {
    link.addEventListener('click', () => toggleMenu(false));
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && drawer.classList.contains('open')) {
      toggleMenu(false);
    }
  });
}

/* --------------------------------------------------------------------------
 * 2. Project Category Filtering
 * -------------------------------------------------------------------------- */
function initProjectFilters() {
  const tabs = document.querySelectorAll('.filter-tab');
  const cards = document.querySelectorAll('.work-card');

  if (!tabs.length || !cards.length) return;

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      // Update active tab state
      tabs.forEach(t => {
        t.classList.remove('active');
        t.setAttribute('aria-selected', 'false');
      });
      tab.classList.add('active');
      tab.setAttribute('aria-selected', 'true');

      const filterValue = tab.getAttribute('data-filter');

      cards.forEach(card => {
        const category = card.getAttribute('data-category');
        if (filterValue === 'all' || category === filterValue) {
          card.style.display = 'flex';
          card.style.opacity = '1';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });
}

/* --------------------------------------------------------------------------
 * 3. Case Study Modal Engine
 * -------------------------------------------------------------------------- */
const CASE_STUDIES = {
  vesper: {
    title: 'The Monolithic Light Pavilion',
    category: 'Spatial Architecture & Interior',
    client: 'Atelier Vesper',
    location: 'Milan, Italy',
    image: 'images/project-spatial.jpg',
    stats: [
      { label: 'Surface Area', value: '320 m²' },
      { label: 'Visitor Dwell Time', value: '+185%' },
      { label: 'Natural Daylight Harvest', value: '74%' }
    ],
    narrative: [
      'Atelier Vesper commissioned Tanasuq to conceptualize and execute a sanctuary for modern craft in Milan’s Brera design quarter. The premise was rooted in total architectural stillness: eliminating visual noise to focus the senses on bespoke couture and sculptural objects.',
      'We designed an uninterrupted barrel-vaulted ceiling paired with textured lime plaster walls hand-troweled over four weeks. The bespoke monolithic oak bench sits in precise mathematical dialogue with the curved aperture, allowing morning sunbeams to cast kinetic arcs across the polished concrete floor.',
      'The result is a tranquil, immersive architectural landscape that doubled client dwell time and was nominated for the Milan Excellence in Interior Architecture Citation.'
    ]
  },
  avalon: {
    title: 'Heritage Reimagined Identity',
    category: 'Brand Identity & Editorial Systems',
    client: 'Avalon & Co.',
    location: 'London & Paris',
    image: 'images/project-brand.jpg',
    stats: [
      { label: 'Recognition', value: 'Gold Award (EDA)' },
      { label: 'Stationery Tactility', value: '640gsm Cotton' },
      { label: 'Brand Inbound Growth', value: '+142%' }
    ],
    narrative: [
      'Avalon & Co. has specialized in mechanical timepieces and archival chronometers for three generations. Their identity required a sensitive balance: preserving generational provenance while projecting modern typographic precision.',
      'Tanasuq drew a bespoke serif logotype rooted in Didone proportions, paired with a custom blind-embossed laurel crest. Every piece of correspondence was specified on custom-milled Gmund cotton stock with wax seals hand-cast in antique bronze.',
      'The unified packaging suite and editorial monographs elevated the brand’s positioning across international luxury retailers, earning the European Design Trophy.'
    ]
  },
  forma: {
    title: 'Form & Texture Curatorial Archive',
    category: 'Digital Products & Monograph',
    client: 'Studio Forma Archive',
    location: 'Zurich, Switzerland',
    image: 'images/project-digital.jpg',
    stats: [
      { label: 'Page Load Speed', value: '0.4s (100 Lighthouse)' },
      { label: 'Inbound Inquiries', value: '2.4x Multiplier' },
      { label: 'Archival Works Indexed', value: '1,400+ Exhibits' },
    ],
    narrative: [
      'For Swiss design institution Studio Forma, we engineered a digital gallery monograph that mirrors the sensory stillness of physical gallery spaces. Every layout adopts strict modular grid math.',
      'Rather than relying on heavy JavaScript frameworks, we built a bespoke, zero-bloat platform prioritizing lightning-fast rendering, typography-first hierarchy, and high-fidelity photography reproduction.',
      'The digital monograph achieved immediate critical acclaim in the global design community and generated over 2,400 catalog orders within its debut month.'
    ]
  }
};

function initCaseStudyModal() {
  const modal = document.getElementById('caseStudyModal');
  const modalBody = document.getElementById('modalBody');
  const closeBtn = document.getElementById('modalCloseBtn');
  const triggerBtns = document.querySelectorAll('.work-cta-btn');

  if (!modal || !modalBody || !closeBtn) return;

  function openModal(projectId) {
    const study = CASE_STUDIES[projectId];
    if (!study) return;

    modalBody.innerHTML = `
      <div class="modal-header-meta">
        <span>${study.category}</span>
        <span aria-hidden="true">·</span>
        <span>${study.client}</span>
        <span aria-hidden="true">·</span>
        <span>${study.location}</span>
      </div>
      <h2 class="modal-title">${study.title}</h2>
      <div class="modal-img-wrapper">
        <img src="${study.image}" alt="${study.title}" class="modal-img">
      </div>
      <div class="modal-details-grid">
        ${study.stats.map(s => `
          <div class="modal-stat-box">
            <span class="modal-stat-label">${s.label}</span>
            <span class="modal-stat-value">${s.value}</span>
          </div>
        `).join('')}
      </div>
      <div class="modal-prose">
        ${study.narrative.map(p => `<p>${p}</p>`).join('')}
      </div>
    `;

    modal.classList.add('open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function closeModal() {
    modal.classList.remove('open');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  triggerBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const proj = btn.getAttribute('data-project');
      openModal(proj);
    });
  });

  closeBtn.addEventListener('click', closeModal);

  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      closeModal();
    }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('open')) {
      closeModal();
    }
  });
}

/* --------------------------------------------------------------------------
 * 4. Interactive Scope & Investment Estimator
 * -------------------------------------------------------------------------- */
function initScopeEstimator() {
  const serviceCheckboxes = document.querySelectorAll('input[name="service"]');
  const scaleSelect = document.getElementById('scaleSelect');
  const timelineSelect = document.getElementById('timelineSelect');
  const estDurationEl = document.getElementById('estDuration');
  const estBudgetEl = document.getElementById('estBudget');
  const breakdownEl = document.getElementById('resultBreakdown');
  const applyBtn = document.getElementById('btnUseEstimator');

  if (!serviceCheckboxes.length || !scaleSelect || !estDurationEl || !estBudgetEl) return;

  function recalculate() {
    let selectedServices = [];
    serviceCheckboxes.forEach(cb => {
      if (cb.checked) selectedServices.push(cb.value);
    });

    if (selectedServices.length === 0) {
      // Keep at least one selected
      const first = serviceCheckboxes[0];
      first.checked = true;
      selectedServices.push(first.value);
    }

    const scale = scaleSelect.value;
    const timeline = timelineSelect.value;

    let baseMinWeeks = 4;
    let baseMaxWeeks = 6;
    let baseMinCost = 6000;
    let baseMaxCost = 10000;
    let items = [];

    // Service contributions
    if (selectedServices.includes('spatial')) {
      baseMinWeeks += 4;
      baseMaxWeeks += 6;
      baseMinCost += 8000;
      baseMaxCost += 14000;
      items.push({ label: 'Spatial Architecture & Material Spec', status: 'Included' });
    }
    if (selectedServices.includes('brand')) {
      baseMinWeeks += 2;
      baseMaxWeeks += 4;
      baseMinCost += 5000;
      baseMaxCost += 8000;
      items.push({ label: 'Brand Identity & Editorial System', status: 'Included' });
    }
    if (selectedServices.includes('digital')) {
      baseMinWeeks += 3;
      baseMaxWeeks += 5;
      baseMinCost += 6000;
      baseMaxCost += 11000;
      items.push({ label: 'Bespoke Digital Platform & Code', status: 'Included' });
    }
    if (selectedServices.includes('artdir')) {
      baseMinWeeks += 1;
      baseMaxWeeks += 2;
      baseMinCost += 3500;
      baseMaxCost += 5500;
      items.push({ label: 'Art Direction & Photography Production', status: 'Included' });
    }

    // Scale multiplier
    let scaleMultiplier = 1;
    if (scale === 'boutique') scaleMultiplier = 0.85;
    if (scale === 'medium') scaleMultiplier = 1.15;
    if (scale === 'flagship') scaleMultiplier = 1.65;

    // Timeline modifier
    let speedCostMultiplier = 1;
    if (timeline === 'accelerated') {
      speedCostMultiplier = 1.25;
      baseMinWeeks = Math.max(3, Math.round(baseMinWeeks * 0.75));
      baseMaxWeeks = Math.max(4, Math.round(baseMaxWeeks * 0.8));
    } else if (timeline === 'flexible') {
      baseMaxWeeks = Math.round(baseMaxWeeks * 1.3);
    }

    const finalMinCost = Math.round((baseMinCost * scaleMultiplier * speedCostMultiplier) / 500) * 500;
    const finalMaxCost = Math.round((baseMaxCost * scaleMultiplier * speedCostMultiplier) / 500) * 500;

    estDurationEl.textContent = `${baseMinWeeks} – ${baseMaxWeeks} Wks`;
    estBudgetEl.textContent = `$${finalMinCost.toLocaleString()} – $${finalMaxCost.toLocaleString()}`;

    // Render breakdown items
    items.push({ label: 'Direct Partner Lead Oversight', status: 'Included' });
    breakdownEl.innerHTML = items.map(it => `
      <div class="breakdown-item">
        <span>${it.label}</span>
        <span class="tabular-nums">${it.status}</span>
      </div>
    `).join('');
  }

  serviceCheckboxes.forEach(cb => cb.addEventListener('change', recalculate));
  scaleSelect.addEventListener('change', recalculate);
  timelineSelect.addEventListener('change', recalculate);

  // Initial calculation
  recalculate();

  // Apply to form
  if (applyBtn) {
    applyBtn.addEventListener('click', () => {
      const contactSection = document.getElementById('contact');
      if (contactSection) {
        contactSection.scrollIntoView({ behavior: 'smooth' });
      }

      // Populate discipline
      const disciplineSelect = document.getElementById('disciplineRequired');
      const budgetSelect = document.getElementById('clientBudget');
      const messageInput = document.getElementById('clientMessage');

      const selected = [];
      serviceCheckboxes.forEach(cb => { if (cb.checked) selected.push(cb.value); });

      if (disciplineSelect) {
        if (selected.length > 1) {
          disciplineSelect.value = 'Comprehensive Cross-Disciplinary';
        } else if (selected.includes('spatial')) {
          disciplineSelect.value = 'Spatial Architecture';
        } else if (selected.includes('brand')) {
          disciplineSelect.value = 'Brand Identity';
        } else if (selected.includes('digital')) {
          disciplineSelect.value = 'Digital Experience';
        }
      }

      if (budgetSelect) {
        budgetSelect.value = '$20,000 - $40,000';
      }

      if (messageInput && !messageInput.value) {
        messageInput.value = `Estimated parameters: ${estDurationEl.textContent} timeline horizon, scope calibrated via Tanasuq studio calculator.`;
      }
    });
  }
}

/* --------------------------------------------------------------------------
 * 5. Contact Form Validation & Submission
 * -------------------------------------------------------------------------- */
function initContactForm() {
  const form = document.getElementById('contactForm');
  const successBanner = document.getElementById('formSuccess');
  const submitBtn = document.getElementById('submitBtn');

  if (!form) return;

  const nameInput = document.getElementById('clientName');
  const emailInput = document.getElementById('clientEmail');
  const disciplineInput = document.getElementById('disciplineRequired');
  const budgetInput = document.getElementById('clientBudget');
  const messageInput = document.getElementById('clientMessage');

  const nameError = document.getElementById('nameError');
  const emailError = document.getElementById('emailError');
  const disciplineError = document.getElementById('disciplineError');
  const budgetError = document.getElementById('budgetError');
  const messageError = document.getElementById('messageError');

  function clearErrors() {
    [nameError, emailError, disciplineError, budgetError, messageError].forEach(el => {
      if (el) el.textContent = '';
    });
  }

  function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    clearErrors();

    let isValid = true;

    if (!nameInput.value.trim()) {
      nameError.textContent = 'Please enter your name.';
      isValid = false;
    }

    if (!emailInput.value.trim()) {
      emailError.textContent = 'Please enter your email.';
      isValid = false;
    } else if (!validateEmail(emailInput.value.trim())) {
      emailError.textContent = 'Please provide a valid email address.';
      isValid = false;
    }

    if (!disciplineInput.value) {
      disciplineError.textContent = 'Please select a primary discipline.';
      isValid = false;
    }

    if (!budgetInput.value) {
      budgetError.textContent = 'Please select an estimated budget tier.';
      isValid = false;
    }

    if (!messageInput.value.trim()) {
      messageError.textContent = 'Please provide a brief description of your vision.';
      isValid = false;
    }

    if (!isValid) return;

    // Simulation of clean submission
    submitBtn.disabled = true;
    submitBtn.textContent = 'Dispatching Brief...';

    setTimeout(() => {
      submitBtn.style.display = 'none';
      if (successBanner) {
        successBanner.style.display = 'block';
        successBanner.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
      form.reset();
    }, 600);
  });
}

/* --------------------------------------------------------------------------
 * 6. Year Sync
 * -------------------------------------------------------------------------- */
function initCurrentYear() {
  const yearEl = document.getElementById('currentYear');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
}
